import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  base: "/uatmioot/uidesign/React/Working/practice/",
  server: {
    historyApiFallback: true,
    watch: {
      ignored: ["**/*.zip"],
    },
  },
});
